export const home_photos = [{
  image: "/images/tests/diamantino2.jpg", 
  label: "Ministério ",
  title: `DIAMANTINO AZEVEDO DESTACA GANHOS DO SECTOR MINEIRO ANGOLANO`,
  sub:"Subtitulo de teste",
  href: "/view/0",
},
{
  image: "/images/tests/paulo.jpeg", 
  label: `Destaque`,
  title: `Garante Benedito Manuel em Nova Iorque`,
  sub:`CATOCA reafirma compromisso com políticas de
responsabilidade social corporativa 
Esta confirmado o compromisso da Sociedade Mineira de
Catoca com a manutenção e o reforço das políticas de
responsabilidade social corporativa.`,
href: "/view/1",
},

{
  image: "/images/tests/future.webp", 
  label: `Destaque`,
  title: `Pensar agora com olhos no futuro`,
  sub:`O anúncio governamental de uma séria aposta na transformação local de
toda a produção extraída do solo angolano é motivo mais do que
suficiente para  encher de orgulho toda uma Nação que augura um
rápido e saudável crescimento económico.`,
href: "/view/2"
},
]
